# IRIS-Flower-classification

<img src="https://miro.medium.com/max/875/1*7bnLKsChXq94QjtAiRn40w.png">

This Project is thorugh application of machine learning with python programming.
It focuses on IRIS flower classification using Machine Learning with scikit tools. 
Here some of algorithm are used that are some types of machine learning subparts algorithms of supervised and Unsupervised learning.
Algorithm used for predicting and get accuracy are -
1. Dicision tree classifier 
2. K nearest classifier
3. SVM
4. Logistic Regression 
5. metrics
6. train_test_split
We are making accuracy and prediction in Iris project through Iris Dataset.
This is easy and understable for machine learning staters( Naive ).

PS: Please do not forget to drop a star if you like it!
