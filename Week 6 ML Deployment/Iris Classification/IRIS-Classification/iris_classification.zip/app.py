from flask import Flask, render_template, request
import pickle
import numpy as np
import pandas as pd

# Initialize Flask app
app = Flask(__name__)

# Load the trained model (You should have saved this model with pickle)
model = None
with open("iris_model.pkl", "rb") as f:
    model = pickle.load(f)

# Route to handle predictions
@app.route('/predict', methods=['POST'])
def predict():
    if request.method == 'POST':
        try:
            # Retrieve user input from form (sepal length, sepal width, etc.)
            sepal_length = float(request.form['sepal_length'])
            sepal_width = float(request.form['sepal_width'])
            petal_length = float(request.form['petal_length'])
            petal_width = float(request.form['petal_width'])

            # Prepare the features array (as a numpy array for the model)
            features = np.array([sepal_length, sepal_width, petal_length, petal_width]).reshape(1, -1)

            # Predict using the model
            prediction = model.predict(features)
            species = prediction[0]

            # Return the prediction result to the frontend
            return render_template('result.html', species=species)

        except Exception as e:
            return f"Error during prediction: {str(e)}"

# Home route (index.html with the input form)
@app.route('/')
def home():
    return render_template('index.html')

if __name__ == "__main__":
    app.run(debug=False, host='0.0.0.0', port=80)
